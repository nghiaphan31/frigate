# /jffs/scripts/export_clients.sh
#!/bin/sh
# Export inventory to /tmp/clients.csv with columns:
# IP,Name,MAC,Vendor,LastSeen,Source,Type,Band,RSSI,TxRate,RxRate,ARPState,APMAC
# Works on Asuswrt-Merlin (gnuton) / BusyBox. No nested awk-in-awk quoting.

OUT="/tmp/clients.csv"
TMP_DIR="/tmp/export_clients.$$"
OUI_CSV="/jffs/etc/oui.csv"
OUI_URL="https://standards-oui.ieee.org/oui/oui.csv"

mkdir -p "$TMP_DIR" /jffs/etc
TMP_DHCP="$TMP_DIR/dhcp"          # ip,name,mac,seen,src,iface,band,rssi,tx,rx,arp,thint
TMP_STATIC="$TMP_DIR/static"
TMP_CUST="$TMP_DIR/custom"
TMP_WIFI="$TMP_DIR/wifi"
TMP_NEI="$TMP_DIR/nei"            # ip,mac,seen,state,dev
TMP_BRMAP="$TMP_DIR/brmap"        # mac,dev  (bridge FDB)
TMP_RAW="$TMP_DIR/raw"
: > "$TMP_DHCP"; : > "$TMP_STATIC"; : > "$TMP_CUST"; : > "$TMP_WIFI"; : > "$TMP_NEI"; : > "$TMP_BRMAP"

NOW_EPOCH="$(date +%s 2>/dev/null || busybox date +%s)"

# Try to ensure we have an OUI database (best effort; safe to skip if no WAN)
if [ ! -s "$OUI_CSV" ]; then
  if command -v wget >/dev/null 2>&1; then
    wget -q -O "$OUI_CSV" "$OUI_URL" 2>/dev/null
  elif command -v curl >/dev/null 2>&1; then
    curl -fsSL "$OUI_URL" -o "$OUI_CSV" 2>/dev/null
  fi
fi

# helper to emit a uniform 12-field line (no APMAC yet; added at the end)
emit12() { printf "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n" "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" "${10}" "${11}" "${12}"; }

# 1) DHCP leases (dnsmasq: expiry mac ip hostname clientid)
for f in /tmp/dhcp.leases /var/lib/misc/dnsmasq.leases /tmp/dnsmasq.leases; do
  if [ -f "$f" ]; then
    awk -v now="$NOW_EPOCH" '
      { hn=$4; if(hn=="*") hn="";
        printf "%s,%s,%s,%s,%s\n", $3,hn,tolower($2),now,"DHCP"
      }' "$f" \
    | while IFS=, read -r ip name mac seen src; do
        emit12 "$ip" "$name" "$mac" "$seen" "$src" "" "" "" "" "" "" ""
      done >> "$TMP_DHCP"
  fi
done

# 2) Static DHCP reservations + custom names (NVRAM)
dsl="$(nvram get dhcp_staticlist 2>/dev/null)"
if [ -n "$dsl" ]; then
  echo "$dsl" | awk -v RS="<" -v now="$NOW_EPOCH" '
    { gsub(/[<>]/," "); n=split($0,a,">");
      if(n>=3){ mac=a[1]; ip=a[2]; name=a[3];
        if(mac!="" && ip!=""){ printf "%s,%s,%s,%s\n", ip,name,tolower(mac),now }
      }}' \
  | while IFS=, read -r ip name mac seen; do
      emit12 "$ip" "$name" "$mac" "$seen" "Static" "" "" "" "" "" "" ""
    done >> "$TMP_STATIC"
fi

ccl="$(nvram get custom_clientlist 2>/dev/null)"
if [ -n "$ccl" ]; then
  echo "$ccl" | awk -v RS="<" -v now="$NOW_EPOCH" '
    { gsub(/[<>]/," "); n=split($0,a,">");
      if(n>=2){ mac=a[1]; name=a[2];
        if(mac!="" && name!=""){ printf "%s,%s,%s\n", name,tolower(mac),now }
      }}' \
  | while IFS=, read -r name mac seen; do
      emit12 "" "$name" "$mac" "$seen" "CustomName" "" "" "" "" "" "" ""
    done >> "$TMP_CUST"
fi

# 3) Wi-Fi associations (prefer iw on AX58U V2)
if command -v iw >/dev/null 2>&1; then
  iw dev 2>/dev/null | awk '/Interface/ {print $2}' | while read iface; do
    band=""; freq="$(iw dev "$iface" info 2>/dev/null | awk "/channel/ {print \$(NF)}" | head -n1)"
    case "$freq" in '' ) band="";; * ) [ "$freq" -lt 3000 ] && band="2.4GHz" || band="5GHz";; esac

    iw dev "$iface" station dump 2>/dev/null | awk -v now="$NOW_EPOCH" -v iface="$iface" -v band="$band" '
      function flush() {
        if(mac!=""){
          if(inactive_ms=="") inactive_ms=0;
          last_seen = now - int(inactive_ms/1000)
          gsub(/[^0-9.]/,"",txrate); gsub(/[^0-9.]/,"",rxrate)
          printf "%s,%s,%s,%s,%s,%s\n", mac,last_seen,signal,txrate,rxrate,iface"|"band
        }
        mac=""; inactive_ms=""; signal=""; txrate=""; rxrate=""
      }
      /^Station /   { flush(); mac=tolower($2) }
      /inactive time:/ { gsub(/[^0-9]/,"",$3); inactive_ms=$3 }
      /^signal:/    { signal=$2 }
      /^tx bitrate:/{
        for(i=1;i<=NF;i++) if($i=="bitrate:"){ txrate=$(i+1) }
      }
      /^rx bitrate:/{
        for(i=1;i<=NF;i++) if($i=="bitrate:"){ rxrate=$(i+1) }
      }
      END{ flush() }
    ' | while IFS=, read -r mac seen rssi tx rx ifb; do
         iface_name="${ifb%%|*}"; band_val="${ifb##*|}"
         emit12 "" "" "$mac" "$seen" "WiFi" "$iface_name" "$band_val" "$rssi" "$tx" "$rx" "" "WiFi"
       done
  done >> "$TMP_WIFI"
elif command -v wl >/dev/null 2>&1; then
  for i in br0 wl0 wl1 wl0.1 wl1.1; do
    if wl -i "$i" assoclist >/dev/null 2>&1; then
      wl -i "$i" assoclist | awk -v now="$NOW_EPOCH" -v iface="$i" '{print tolower($2)","now","iface}' \
      | while IFS=, read -r mac seen ifc; do
          emit12 "" "" "$mac" "$seen" "WiFi" "$ifc" "" "" "" "" "" "WiFi"
        done
    fi
  done >> "$TMP_WIFI"
fi

# 4) Neighbors (ip neigh preferred; fallback arp) with ARP state + dev
if command -v ip >/dev/null 2>&1; then
  ip neigh 2>/dev/null | awk -v now="$NOW_EPOCH" '
    $0 ~ /lladdr/ {
      ip=$1; dev=""; mac=""; state=$(NF)
      for(i=1;i<=NF;i++){ if($i=="lladdr"){mac=$(i+1)}; if($i=="dev"){dev=$(i+1)} }
      if(ip ~ /^[0-9.]+$/ && mac!=""){ printf "%s,%s,%s,%s,%s\n", ip,tolower(mac),now,state,dev }
    }' >> "$TMP_NEI"
else
  arp -n 2>/dev/null | awk -v now="$NOW_EPOCH" '
    / at / && / on / {
      match($0, /\(([0-9.]+)\)/, a); ip=a[1]
      match($0, / at ([0-9a-f:]{17}) /, b); mac=b[1]
      match($0, / on ([^ ]+)$/, c); dev=c[1]
      if(ip!="" && mac!="") printf "%s,%s,%s,%s,%s\n", ip,tolower(mac),now,"",dev
    }' >> "$TMP_NEI"
fi

# 5) Bridge FDB (client MAC -> ingress device)
if command -v bridge >/dev/null 2>&1; then
  bridge fdb show br0 2>/dev/null | awk '
    {
      mac=tolower($1); dev="";
      for(i=1;i<=NF;i++) if($i=="dev"){dev=$(i+1)}
      if(mac ~ /^[0-9a-f:]{17}$/ && dev!=""){ print mac","dev }
    }' > "$TMP_BRMAP"
elif command -v brctl >/dev/null 2>&1; then
  brctl showmacs br0 2>/dev/null | awk '{if($2 ~ /..:..:..:..:..:../){print tolower($2)",""port"$1}}' > "$TMP_BRMAP"
fi

# 6) Merge + vendor lookup + APMAC inference (ALL IN ONE AWK)
awk -F, -v OFS=',' -v OUI="$OUI_CSV" -v NEI="$TMP_NEI" -v BRMAP="$TMP_BRMAP" '
  # Incoming fields: 1 ip,2 name,3 mac,4 seen,5 src,6 iface,7 band,8 rssi,9 tx,10 rx,11 arp,12 typehint

  # --- preload OUI map (robust parse for quoted CSV: "Assignment","Organization Name",...) ---
  function up(s){gsub(/[a-f]/,"",s); return toupper(s)}  # minimal helper
  BEGIN{
    if(OUI!=""){
      while((getline line < OUI)>0){
        # try to capture first two quoted fields: "XXXXXX","Vendor"
        if(line ~ /^"/){
          # find first closing quote after opening
          p1 = index(line, "\""); if(p1==0) continue
          p2 = index(substr(line, p1+1), "\""); if(p2==0) continue
          key = substr(line, p1+1, p2-1)
          rest = substr(line, p1+p2+1)
          # next quoted field
          q1 = index(rest, "\""); if(q1==0) continue
          q2 = index(substr(rest, q1+1), "\""); if(q2==0) continue
          val = substr(rest, q1+1, q2-1)
          gsub(/^[ \t]+|[ \t]+$/, "", val)
          if(length(key)==6){ ouimap[key]=val }
        }
      }
      close(OUI)
    }

    # preload neighbor table (dev + state) and device->neighbors set
    while((getline nline < NEI)>0){
      split(nline,a,","); nip=a[1]; nmac=a[2]; nseen=a[3]; nstate=a[4]; ndev=a[5]
      if(nmac!=""){ neigh_dev[nmac]=ndev; neigh_state[nmac]=nstate }
      if(ndev!=""){ dev_neighbors[ndev SUBSEP nmac]=1 }
    }
    close(NEI)

    # preload bridge fdb map
    while((getline bline < BRMAP)>0){
      split(bline,b,","); bmac=b[1]; bdev=b[2]
      if(bmac!="" && bdev!=""){ brdev[bmac]=bdev }
    }
    close(BRMAP)
  }

  function oui(mac,  p) {
    if(mac=="") return "Unknown"
    split(mac,m,":"); p=toupper(m[1] m[2] m[3])
    if(p in ouimap) return ouimap[p]
    return "Unknown"
  }
  function weight(src){ return (src=="DHCP")?5:(src=="Static")?4:(src=="Neighbor")?3:(src=="WiFi")?2:(src=="CustomName")?1:0 }
  function addsrc(cur,s){ if(s=="") return cur; if(cur=="") return s; n=split(cur,parts,"+"); for(i=1;i<=n;i++) if(parts[i]==s) return cur; return cur "+" s }

  # is this vendor likely an AP brand? (crude heuristic)
  function is_ap_vendor(v, V){
    V=toupper(v)
    return (index(V,"TP-LINK")||index(V,"UBIQUITI")||index(V,"CISCO")||index(V,"ARUBA")||index(V,"NETGEAR")||index(V,"MIKROTIK")||index(V,"HUAWEI")||index(V,"ZYXEL")||index(V,"ENGENIUS")||index(V,"D-LINK")||index(V,"TENDA")||index(V,"MERCURY")||index(V,"TOTOLINK"))
  }

  {
    ip=$1; name=$2; mac=tolower($3); seen=$4; src=$5; iface=$6; band=$7; rssi=$8; tx=$9; rx=$10; arp=$11; th=$12
    gsub(/^[ \t]+|[ \t]+$/,"",name)
    if(mac=="") next

    if(!(mac in seen_any)){
      seen_any[mac]=1; nm[mac]=name; ipm[mac]=ip; ipsrc[mac]=src; lm[mac]=seen; srcs[mac]=src
      ifs[mac]=iface; bnd[mac]=band; sig[mac]=rssi; txr[mac]=tx; rxr[mac]=rx; arpst[mac]=arp; typeh[mac]=th
      ord[++n]=mac
    } else {
      if(nm[mac]=="" && name!="") nm[mac]=name
      if(seen!="" && seen>lm[mac]) lm[mac]=seen
      if(ip!="" && (ipm[mac]=="" || weight(src)>weight(ipsrc[mac]))){ ipm[mac]=ip; ipsrc[mac]=src }
      if(ifs[mac]=="" && iface!="") ifs[mac]=iface
      if(bnd[mac]=="" && band!="")  bnd[mac]=band
      if(sig[mac]=="" && rssi!="")  sig[mac]=rssi
      if(txr[mac]=="" && tx!="")    txr[mac]=tx
      if(rxr[mac]=="" && rx!="")    rxr[mac]=rx
      if(arpst[mac]=="" && arp!="") arpst[mac]=arp
      if(typeh[mac]=="" && th!="")  typeh[mac]=th
      srcs[mac]=addsrc(srcs[mac], src)
    }
  }

  # infer upstream AP MAC for client cmac
  function infer_apmac(cmac,   dev, k, pair, d, m, vend) {
    # If we saw it on Asus Wi-Fi, mark as such
    if(index(srcs[cmac],"WiFi")) return "AsusWiFi"

    # which bridge dev learned this MAC?
    dev = brdev[cmac]; if(dev=="") dev=neigh_dev[cmac]

    if(dev!=""){
      # scan neighbors on that dev; pick first with AP-like vendor
      for(pair in dev_neighbors){
        split(pair,km,SUBSEP); d=km[0]; m=km[1]  # BusyBox awk uses 0/1? safer: recompute
      }
      # Re-iterate safely:
      for(pair in dev_neighbors){
        split(pair,km,SUBSEP); d=km[1]; m=km[2]
        if(d!=dev) continue
        vend = oui(m)
        if(is_ap_vendor(vend)) return m
      }
      return "LAN"
    }
    return ""
  }

  END{
    # sort by IP asc; no asort in busybox -> manual index sort
    for(i=1;i<=n;i++){
      mac=ord[i]; ip=ipm[mac]
      if(ip ~ /^[0-9.]+$/){ split(ip,a,"."); key=sprintf("%03d.%03d.%03d.%03d",a[1],a[2],a[3],a[4]) }
      else key=sprintf("999.%09d", i)
      sortkey[i]=key
    }
    for(i=1;i<=n;i++) rk[i]=i
    for(i=1;i<=n;i++) for(j=i+1;j<=n;j++) if(sortkey[rk[i]]>sortkey[rk[j]]){ t=rk[i]; rk[i]=rk[j]; rk[j]=t }

    # RAW header
    print "IP,Name,MAC,Vendor,LastSeen,Source,Type,Band,RSSI,TxRate,RxRate,ARPState,APMAC"
    for(x=1;x<=n;x++){
      i=rk[x]; mac=ord[i]; ip=ipm[mac]; name=nm[mac]; last=lm[mac]; src=srcs[mac]
      typ = (typeh[mac]=="" ? (bnd[mac]!=""?"WiFi":"Wired") : typeh[mac])
      ap  = infer_apmac(mac)
      print ip, name, mac, oui(mac), last, src, typ, bnd[mac], sig[mac], txr[mac], rxr[mac], arpst[mac], ap
    }
  }
' "$TMP_DHCP" "$TMP_STATIC" "$TMP_CUST" "$TMP_WIFI" "$TMP_NEI" > "$TMP_RAW"

# 7) Convert epoch -> ISO 8601 UTC and finalize
echo "IP,Name,MAC,Vendor,LastSeen,Source,Type,Band,RSSI,TxRate,RxRate,ARPState,APMAC" > "$OUT"
while IFS=, read -r ip name mac vendor epoch sources typ band rssi tx rx arp apmac; do
  [ "$ip" = "IP" ] && continue
  if iso="$(date -u -d "@$epoch" "+%Y-%m-%d %H:%M:%SZ" 2>/dev/null)"; then :
  elif iso="$(busybox date -u -D %s -d "$epoch" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null)"; then :
  else iso="$epoch"; fi
  echo "$ip,$name,$mac,$vendor,$iso,$sources,$typ,$band,$rssi,$tx,$rx,$arp,$apmac"
done < "$TMP_RAW" >> "$OUT"

echo "Wrote $OUT"
tail -n +1 "$OUT"

rm -rf "$TMP_DIR"
